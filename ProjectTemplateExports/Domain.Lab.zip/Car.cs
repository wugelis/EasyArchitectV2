﻿
namespace $safeprojectname$
{
    public class Car : IVehicle
    {
        private ModelType _modelName;
        public ModelType Model { get => _modelName; set => value = _modelName; }
        public string CC { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public Car(ModelType modelName)
        {
            _modelName = modelName;
        }
        public int CalculateRentalCost(int daysRented)
        {
            return daysRented * (int)_modelName;
        }

        public TimeSpan ChoiseRentalTime(DateTime start, DateTime end)
        {
            throw new NotImplementedException();
        }

        public VehicleType GetVehicleType()
        {
            throw new NotImplementedException();
        }
    }
}
