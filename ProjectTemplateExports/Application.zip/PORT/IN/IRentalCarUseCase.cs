﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Lab20240821.port.In
{
    public interface IRentalCarUseCase
    {
        bool ToRentCar(Domain.Lab120240821.IVehicle car);
    }
}
